import { authenticateMl } from '../shared/utils/authenticate_CDSE_ML'
import { getCdseTokenForUser, CdseNotConnectedError } from '../shared/services/cdseTokenService'
import { connectDb } from '../shared/mongo/db'
import { ensureParcelConnected } from '../shared/mongo/connections'
import { mlWeatherStore } from '../shared/mongo/models/MlWeather'
import { syncDates, syncMlDates, fetchWeather } from '../shared/services/ndviService'


export const handler = async (event: any) => {
  
  // testiä varten
  //if (event.name === "FAIL") throw new Error("testivirhe");

  await connectDb()

  const geometry = typeof event.geometry !== 'object'
    ? JSON.parse(event.geometry)
    : event.geometry

  // ── ML-ajo: tallennus ML_data- ja ML_weather-kokoelmiin, ei kuvia ──
  if (event.target === 'ml') {
    const authToken = await authenticateMl(event.credIndex ?? 0)
    console.log('ML: start', event.field_id)
    await ensureParcelConnected()
    console.log('ML: parcel connected')

    const mlResult = await syncMlDates(
      geometry,
      new Date(event.start_date),
      new Date(event.end_date),
      authToken,
      event.batchId ?? '',
      event.kasvulohkot ?? [],
      {
        peruslohkotunnus: event.peruslohkotunnus,
        vuosi: event.vuosi,
        pinta_ala: event.pinta_ala,
      }
    )
    console.log('ML: syncMlDates done', !!mlResult)

    if (mlResult) await fetchWeather(mlResult.geometry, mlResult.seasons, mlWeatherStore)
    console.log('ML: weather done')

    return {
      geometry: mlResult?.geometry ?? geometry,
      field_id: event.field_id,
      jobId: event.jobId,
      aoiId: event.aoiId,
      items: []
    }
  }

  // ── Normaali käyttäjän ajo (ennallaan) ──
  if (!event.userId) throw new CdseNotConnectedError()
    const authToken = await getCdseTokenForUser(event.userId)
    const result = await syncDates(
    geometry,
    new Date(event.start_date),
    authToken,
    event.name ?? '',
    event.userId ?? '',
    event.kasvulohkot ?? [],
    false,
    true   // throwOnError: CDSE-virhe ei saa näyttää onnistumiselta
  )

  if (!result) {
    return { geometry, field_id: event.field_id, jobId: event.jobId, aoiId: event.aoiId, userId: event.userId, items: [] }
  }

  await fetchWeather(result.geometry, result.seasons)

  return {
    geometry: result.geometry,
    field_id: event.field_id,
    jobId: event.jobId,
    aoiId: event.aoiId,
    userId: event.userId,
    items: result.newDates
  }
}