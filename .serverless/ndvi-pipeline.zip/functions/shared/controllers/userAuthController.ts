import { Request, Response } from "express";
import { validationResult } from "express-validator";
import {
  registerUserInDb,
  findUserByEmail,
  validatePassword,
  createJwtToken,
  updatePasswordInDb,
  DUMMY_PASSWORD_HASH
} from "../services/userAuthService";

import { createEmailToken } from "../services/tokenService";
import { sendEmail } from "../services/emailService";
import { getTemplates, resolveLang } from "../services/emailTemplates";

import { consumeEmailToken } from "../services/tokenService";
import { User } from "../mongo/models/User";
import {
  CdseAuthError,
  verifyCdseCredentials,
  saveCdseCredentials,
  clearCdseCredentials,
  connectCdseCredentials
} from "../services/cdseCredentialsService";

import { getAllDateSets } from "../mongo/mongodb";
import { removeFieldForUser } from "../services/fieldService";
import { Job } from "../mongo/models/Job";

import { deleteNotesForUser } from "../services/fieldNoteService";

/**
 * How long the email verification link is valid (minutes).
 * Must match the lifetime of the "verify_email" token in tokenService.
 */
const VERIFY_WINDOW_MIN = 60;

/**
 * The unverified user document (with its encrypted CDSE credentials) is
 * deleted automatically by the TTL index at this age. The small margin
 * prevents a race where a link used just before expiry finds the user gone.
 */
const VERIFY_TTL_MARGIN_MIN = 5;

const MAX_CDSE_FIELD_LEN = 200;

const isValidCdseField = (v: unknown): v is string =>
  typeof v === "string" && v.trim().length > 0 && v.length <= MAX_CDSE_FIELD_LEN;


const toErrorList = (errors: ReturnType<typeof validationResult>) =>
  errors.array().map((e) => ({
    path: "path" in e ? e.path : undefined,
    msg: e.msg
  }));

/* =======================================================
   REGISTER USER
   ------------------------------------------------------- */
/**
 * Registers a new user account.
 *
 * @remarks
 * This controller:
 * - validates request body using `express-validator`
 * - verifies the user's own CDSE credentials by fetching a token
 *   (first, so the checks below cannot be probed without working
 *   credentials)
 * - checks whether the CDSE client ID is already in use
 * - checks whether the email is already in use
 * - creates a new user in the database
 * - stores the CDSE secret encrypted and sets the verification deadline
 *   (`verifyExpiresAt`, removed when the email is verified)
 * - returns a generic success message
 *
 * Validation errors return `400 Bad Request`.
 * Rejected CDSE credentials return `422`, CDSE unreachable returns `503`.
 * A CDSE client ID already in use returns `409` with the code
 * `CDSE_ALREADY_IN_USE`.
 * A duplicate email returns the same `201` response as a successful
 * registration, so the API does not reveal which emails have an account
 * (account enumeration).
 *
 * @param req - Express request containing `email`, `password`, `username`,
 *              `clientId` and `clientSecret` (CDSE OAuth client).
 * @param res - Express response returning a generic success message.
 *
 * @returns A JSON response with a message or an error code.
 */
export const registerUser = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: toErrorList(errors) });
  }

  const { email, password, username, clientId, clientSecret } = req.body;

  if (!isValidCdseField(clientId) || !isValidCdseField(clientSecret)) {
    return res.status(400).json({ code: "CDSE_BAD_REQUEST" });
  }
  const cdseCreds = {
    clientId: clientId.trim(),
    clientSecret: clientSecret.trim()
  };

  // Same response for a new and an already registered email
  const genericOk = () =>
    res.status(201).json({
      message: "User registered. Check your email to verify your account."
    });

  try {
    // 1) Verify the CDSE credentials first, so the checks below cannot be
    //    probed without working credentials (account enumeration)
    try {
      await verifyCdseCredentials(cdseCreds);
    } catch (err) {
      if (err instanceof CdseAuthError) {
        return err.kind === "invalid"
          ? // 422 (not 401) so the frontend does not treat it as an expired session
          res.status(422).json({ code: "CDSE_INVALID_CREDENTIALS" })
          : res.status(503).json({ code: "CDSE_UNAVAILABLE" });
      }
      throw err;
    }

    const clientIdTaken = await User.exists({ cdseClientId: cdseCreds.clientId });
    if (clientIdTaken) {
      return res.status(409).json({ code: "CDSE_ALREADY_IN_USE" });
    }

    // Existing email: same response as a successful registration
    const existing = await findUserByEmail(email);
    if (existing) {
      return genericOk();
    }

    const newUser = await registerUserInDb(email, password, username);

    // 2) Deadline first (so a partial failure still cleans itself up via TTL),
    //    then the encrypted credentials. On failure the new user is rolled back.
    try {
      await User.updateOne(
        { _id: newUser._id },
        {
          $set: {
            verifyExpiresAt: new Date(
              Date.now() + (VERIFY_WINDOW_MIN + VERIFY_TTL_MARGIN_MIN) * 60_000
            )
          }
        }
      );
      await saveCdseCredentials(String(newUser._id), cdseCreds);
    } catch (saveErr) {
      console.error(
        "CDSE credentials save failed:",
        saveErr instanceof Error ? saveErr.message : "unknown error"
      );
      await User.deleteOne({ _id: newUser._id });
      return res.status(500).json({ message: "Server error" });
    }

    // Vahvistuslinkki sähköpostiin. Viestin epäonnistuminen ei kaada rekisteröintiä.
    try {
      const token = await createEmailToken(newUser._id, "verify_email");
      const link = `${process.env.APP_URL}/verify-email?token=${token}`;
      const t = getTemplates(resolveLang(req.body.lang));
      await sendEmail(
        newUser.email,
        t.verifySubject,
        t.verifyBody(newUser.username, link, VERIFY_WINDOW_MIN)
      );
    } catch (mailErr) {
      console.error("Verification email error:", mailErr);
    }

    return genericOk();

  } catch (err) {
    console.error("Register error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};

/* =======================================================
   LOGIN USER
   ------------------------------------------------------- */
/**
 * Authenticates a user and returns a JWT token.
 *
 * @remarks
 * This controller:
 * - validates request body using `express-validator`
 * - compares the password against the stored hash, or against a dummy hash
 *   when the user does not exist, so response time does not reveal whether
 *   the email is registered
 * - checks that the email address is verified (only after the password
 *   was correct)
 * - generates a JWT token using `createJwtToken`
 * - returns the token and user profile data
 *
 * Validation errors return `400 Bad Request`.
 * Unknown email or wrong password both return `401` with the code
 * `INVALID_CREDENTIALS`.
 * A correct password with an unverified email returns `403` with the code
 * `EMAIL_NOT_VERIFIED`.
 *
 * @param req - Express request containing `email` and `password`.
 * @param res - Express response returning the JWT and user info.
 *
 * @returns A JSON response with `{ token, user }` or an error code.
 */
export const loginUser = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: toErrorList(errors) });
  }

  //console.log("Login request received for email:", req.body.email);
  try {
    const { email, password } = req.body;

    const user = await findUserByEmail(email);

    // Always run one bcrypt comparison so response time does not reveal
    // whether the email exists
    const match = await validatePassword(
      password,
      user?.password ?? DUMMY_PASSWORD_HASH
    );
    if (!user || !match) {
      return res.status(401).json({ code: "INVALID_CREDENTIALS" });
    }

    if (!user.verified) {
      return res.status(403).json({
        code: "EMAIL_NOT_VERIFIED",
        message: "Email address not verified"
      });
    }

    const token = createJwtToken(user);

    return res.status(200).json({
      token,
      user: {
        id: user._id,
        email: user.email,
        username: user.username
      }
    });

  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};

export const verifyEmailUser = async (req: Request, res: Response) => {
  const { token } = req.body;

  if (typeof token !== "string" || token.length !== 64) {
    return res.status(400).json({ code: "INVALID_OR_EXPIRED_TOKEN" });
  }

  try {
    const userId = await consumeEmailToken(token, "verify_email");
    if (!userId) {
      return res.status(400).json({ code: "INVALID_OR_EXPIRED_TOKEN" });
    }

    // Verified: mark the user and remove the deadline so the TTL index no longer applies
    const result = await User.updateOne(
      { _id: userId },
      { $set: { verified: true }, $unset: { verifyExpiresAt: "" } }
    );
    if (result.matchedCount === 0) {
      // the unverified user was already removed by the TTL index
      return res.status(400).json({ code: "INVALID_OR_EXPIRED_TOKEN" });
    }

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("Verify email error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};

export const updateCdseCredentials = async (req: Request, res: Response) => {
  const userId = (req as Request & { user?: { _id?: unknown } }).user?._id;
  if (!userId) return res.status(401).json({ code: "UNAUTHORIZED" });

  const { clientId, clientSecret } = req.body;
  if (!isValidCdseField(clientId) || !isValidCdseField(clientSecret)) {
    return res.status(400).json({ code: "CDSE_BAD_REQUEST" });
  }

  try {

    const taken = await User.exists({
      cdseClientId: clientId.trim(),
      _id: { $ne: userId }
    });
    if (taken) {
      return res.status(409).json({ code: "CDSE_ALREADY_IN_USE" });
    }
    await connectCdseCredentials(String(userId), {
      clientId: clientId.trim(),
      clientSecret: clientSecret.trim()
    });
    return res.status(200).json({ code: "CDSE_CONNECTED" });
  } catch (err) {
    if (err instanceof CdseAuthError) {
      return err.kind === "invalid"
        ? res.status(422).json({ code: "CDSE_INVALID_CREDENTIALS" })
        : res.status(503).json({ code: "CDSE_UNAVAILABLE" });
    }
    console.error("CDSE update error:", err instanceof Error ? err.message : "unknown error");
    return res.status(500).json({ message: "Server error" });
  }
};

export const deleteCdseCredentials = async (req: Request, res: Response) => {
  const userId = (req as Request & { user?: { _id?: unknown } }).user?._id;
  if (!userId) return res.status(401).json({ code: "UNAUTHORIZED" });

  try {
    await clearCdseCredentials(String(userId));
    return res.status(200).json({ code: "CDSE_DISCONNECTED" });
  } catch (err) {
    console.error("CDSE delete error:", err instanceof Error ? err.message : "unknown error");
    return res.status(500).json({ message: "Server error" });
  }
};

export const getCdseStatus = async (req: Request, res: Response) => {
  const userId = (req as Request & { user?: { _id?: unknown } }).user?._id;
  if (!userId) return res.status(401).json({ code: "UNAUTHORIZED" });

  try {
    const user = await User.findById(String(userId))
      .select("cdseConnected cdseVerifiedAt")
      .lean();
    if (!user) return res.status(401).json({ code: "UNAUTHORIZED" });

    return res.status(200).json({
      connected: user.cdseConnected === true,
      verifiedAt: user.cdseVerifiedAt ?? null
    });
  } catch (err) {
    console.error("CDSE status error:", err instanceof Error ? err.message : "unknown error");
    return res.status(500).json({ message: "Server error" });
  }
};

const RESET_WINDOW_MIN = 30; // sama kuin password_reset TTL tokenService.ts:ssä

export const forgotPassword = async (req: Request, res: Response) => {
  const { email } = req.body;
  if (typeof email !== "string" || email.length === 0) {
    return res.status(400).json({ code: "EMAIL_REQUIRED" });
  }

  // Sama vastaus riippumatta siitä, löytyykö osoite, jotta rajapinnasta
  // ei näe mitkä sähköpostit on rekisteröity
  const okResponse = () =>
    res.status(200).json({ message: "If the email exists, a reset link has been sent." });

  try {
    const user = await findUserByEmail(email.trim());
    if (!user || !user.verified) return okResponse();

    try {
      const token = await createEmailToken(user._id, "password_reset");
      const link = `${process.env.APP_URL}/reset-password?token=${token}`;
      const t = getTemplates(resolveLang(req.body.lang));
      await sendEmail(
        user.email,
        t.resetSubject,
        t.resetBody(user.username, link, RESET_WINDOW_MIN)
      );
    } catch (mailErr) {
      console.error("Password reset email error:", mailErr);
    }

    return okResponse();
  } catch (err) {
    console.error("Forgot password error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};

export const resetPassword = async (req: Request, res: Response) => {
  // Validointi ennen tokenin kulutusta, jotta heikko salasana ei polta linkkiä
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: toErrorList(errors) });
  }

  const { token, password } = req.body;
  if (typeof token !== "string" || token.length !== 64) {
    return res.status(400).json({ code: "INVALID_OR_EXPIRED_TOKEN" });
  }

  try {
    const userId = await consumeEmailToken(token, "password_reset");
    if (!userId) {
      return res.status(400).json({ code: "INVALID_OR_EXPIRED_TOKEN" });
    }

    const updated = await updatePasswordInDb(String(userId), password);
    if (!updated) {
      return res.status(400).json({ code: "INVALID_OR_EXPIRED_TOKEN" });
    }

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("Reset password error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};

export const deleteAccount = async (req: Request, res: Response) => {
  const userId = (req as Request & { user?: { _id?: unknown } }).user?._id;
  if (!userId) return res.status(401).json({ code: "UNAUTHORIZED" });

  const { password } = req.body;
  if (typeof password !== "string" || password.length === 0) {
    return res.status(400).json({ code: "PASSWORD_REQUIRED" });
  }

  try {
    const user = await User.findById(String(userId)).select("+password");
    if (!user) return res.status(401).json({ code: "UNAUTHORIZED" });

    // Salasanavahvistus: sama vertailu kuin kirjautumisessa
    const match = await validatePassword(password, user.password);
    if (!match) {
      // 422 (not 401) so the frontend does not treat it as an expired session
      return res.status(422).json({ code: "INVALID_CREDENTIALS" });
    }

    // 1) Pellot: poistetaan vain käyttäjän merkintä, data (kuvat, sää) poistuu
    //    vasta kun kukaan muu ei jaa peltoa
    const fields = await getAllDateSets(String(userId));
    for (const f of fields) {
      await removeFieldForUser(f.id, String(userId));
    }

    // 2) Käyttäjän jobit
    await Job.deleteMany({ userId: String(userId) });

    // 3) Käyttäjän muistiinpanot (varmistus: myös orvot, joiden pelto ei ole enää listalla)
    await deleteNotesForUser(String(userId));

    // 4) Käyttäjä viimeisenä (salatut CDSE-tunnukset poistuvat dokumentin mukana).
    //    Jos jokin yllä kaatuu, tili on yhä olemassa ja poiston voi ajaa uudelleen.
    await User.deleteOne({ _id: userId });

    return res.status(200).json({ code: "ACCOUNT_DELETED" });
  } catch (err) {
    console.error("Delete account error:", err instanceof Error ? err.message : "unknown error");
    return res.status(500).json({ message: "Server error" });
  }
};